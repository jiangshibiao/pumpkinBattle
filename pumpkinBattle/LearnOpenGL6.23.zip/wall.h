#ifndef _WALL_H_
#define _WALL_H_

#include<stdio.h>
#include<vector>
#include<cmath>
#include "point.h"

using namespace std;

const double clickdist = 3;

class Face {
friend class Wall;
public:
	Face(int live) : live(live) {

	}
	void filp() { live ^= 1; }
private:
	int live;
};


class Wall {
public:
	Wall(Point3D center, Point3D px, Point3D py, Point3D pz, int accx, int accy, int type): 
		center(center), px(px), py(py), pz(pz), accx(accx), accy(accy), type(type),
		xlength((px - center).length()),
		ylength((py - center).length()),
		zlength((pz - center).length()) {
		face.clear();
		for (int i = 0; i < accx; i++) {
			vector<Face>Y;
			for (int j = 0; j < accy; j++)
				Y.push_back(Face(1));
			face.push_back(Y);
		}
		//may be slow
	}
	pair<double, Face*> clicked(const Point3D &circenter, const Point3D &direction);
	void Addface(Point3D A, Point3D B, Point3D C, Point3D D);
	void Display(vector<Cube> &trans);
	vector<Point3D>allface;
private:
	Point3D center, px, py, pz;
	int accx, accy;
	double xlength, ylength, zlength;
	vector<vector<Face> >face;
	int type;
};

extern vector<Wall*> WallManager;

#endif