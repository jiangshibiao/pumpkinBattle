#ifndef _MONSTER_H_
#define _MONSTER_H_

#include "camera.h"
#include "Wall.h"
#include "Model.h"

class Monster : public OurModel{
public:
	int hitpoint;

	Monster(const char *s, Point3D pos, double size, int hitpoint, 
		Point3D centerpos = Point3D(0, 0, 0), double xlength = 0, double ylength = 0, double zlength = 0) :
		OurModel(s, pos, size, 1, centerpos, xlength, ylength, zlength), hitpoint(hitpoint){}
	void Trymove(Point3D goal, double movelen) {
		goal.y = pos.y;

		double nowdis = (goal - pos).length();
		
		if (nowdis > 0.5) {
			int trymodified = rand() % 1000 <= 1;
			if (trymodified){
				int go = rand() % max(1, (int)(goal - pos).length());
				if (go <= 1)
					Front = goal - pos;
				else
					Front = Point3D(rand() % 101 - 50, 0, rand() % 101 - 50);
			}
			pos = pos + Front.resize(movelen);
		}
		Front = Front.resize(1);
		Point3D temp = Point3D(0, 1, 0) * Front;
		if (sgn(temp.length()) != 0)Left = temp;
		Left = Left.resize(1);

		Up = Front * Left;
		Up = Up.resize(1);
	}
	void Hit() {
		--hitpoint;
	}
	bool Checkhitpoint() {
		return hitpoint > 0;
	}
};

#endif