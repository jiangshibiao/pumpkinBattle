#pragma once
#include "point.h"
#include <glad/glad.h>
#include <GLFW/glfw3.h>


void renderCube(unsigned int &cubeVAO, unsigned int &cubeVBO, Point3D texture, bool type = 0)
{

	static float vertices[] = {
		// back face
		-1.0f, -1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 0.0f, 0.0f, // bottom-left
		 1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 1.0f, // top-right
		 1.0f, -1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 0.0f, // bottom-right         
		 1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 1.0f, 1.0f, // top-right
		-1.0f, -1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 0.0f, 0.0f, // bottom-left
		-1.0f,  1.0f, -1.0f,  0.0f,  0.0f, -1.0f, 0.0f, 1.0f, // top-left
		// front face
		-1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f, 0.0f, // bottom-left
		 1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 0.0f, // bottom-right
		 1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 1.0f, // top-right
		 1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, 1.0f, // top-right
		-1.0f,  1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f, 1.0f, // top-left
		-1.0f, -1.0f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f, 0.0f, // bottom-left

		// left face
		-1.0f,  1.0f,  1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 0.0f, // top-right
		-1.0f,  1.0f, -1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 1.0f, // top-left
		-1.0f, -1.0f, -1.0f, -1.0f,  0.0f,  0.0f, 0.0f, 1.0f, // bottom-left
		-1.0f, -1.0f, -1.0f, -1.0f,  0.0f,  0.0f, 0.0f, 1.0f, // bottom-left
		-1.0f, -1.0f,  1.0f, -1.0f,  0.0f,  0.0f, 0.0f, 0.0f, // bottom-right
		-1.0f,  1.0f,  1.0f, -1.0f,  0.0f,  0.0f, 1.0f, 0.0f, // top-right

		// right face
		 1.0f,  1.0f,  1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 0.0f, // top-left
		 1.0f, -1.0f, -1.0f,  1.0f,  0.0f,  0.0f, 0.0f, 1.0f, // bottom-right
		 1.0f,  1.0f, -1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 1.0f, // top-right         
		 1.0f, -1.0f, -1.0f,  1.0f,  0.0f,  0.0f, 0.0f, 1.0f, // bottom-right
		 1.0f,  1.0f,  1.0f,  1.0f,  0.0f,  0.0f, 1.0f, 0.0f, // top-left
		 1.0f, -1.0f,  1.0f,  1.0f,  0.0f,  0.0f, 0.0f, 0.0f, // bottom-left     

		// bottom face
		-1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f, 0.0f, 1.0f, // top-right
		 1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 1.0f, // top-left
		 1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 0.0f, // bottom-left
		 1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f, 1.0f, 0.0f, // bottom-left
		-1.0f, -1.0f,  1.0f,  0.0f, -1.0f,  0.0f, 0.0f, 0.0f, // bottom-right
		-1.0f, -1.0f, -1.0f,  0.0f, -1.0f,  0.0f, 0.0f, 1.0f, // top-right

		// top face
		-1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f, 0.0f, 1.0f, // top-left
		 1.0f,  1.0f , 1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 0.0f, // bottom-right
		 1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 1.0f, // top-right     
		 1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f, 1.0f, 0.0f, // bottom-right
		-1.0f,  1.0f, -1.0f,  0.0f,  1.0f,  0.0f, 0.0f, 1.0f, // top-left
		-1.0f,  1.0f,  1.0f,  0.0f,  1.0f,  0.0f, 0.0f, 0.0f  // bottom-left        

	};
	if (cubeVAO == 0)
	{
		glGenVertexArrays(1, &cubeVAO);
		glGenBuffers(1, &cubeVBO);
		// fill buffer
		glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
		// link vertex attributes
		glBindVertexArray(cubeVAO);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glBindVertexArray(0);
	}


	for (int st = 0; st < 6; st++) {
		vertices[st * 48 + 8 * 0 + 6] = vertices[st * 48 + 8 * 4 + 6] = vertices[st * 48 + 8 * 5 + 6] = 0.05;
		vertices[st * 48 + 8 * 0 + 7] = vertices[st * 48 + 8 * 1 + 7] = vertices[st * 48 + 8 * 5 + 7] = 0.05;
		vertices[st * 48 + 8 * 1 + 6] = vertices[st * 48 + 8 * 2 + 6] = vertices[st * 48 + 8 * 3 + 6] = 0.06;
		vertices[st * 48 + 8 * 2 + 7] = vertices[st * 48 + 8 * 3 + 7] = vertices[st * 48 + 8 * 4 + 7] = 0.06;
	}

	if (type == 0) {
		vertices[0 * 48 + 8 * 0 + 6] = vertices[0 * 48 + 8 * 4 + 6] = vertices[0 * 48 + 8 * 5 + 6] = texture.x;
		vertices[0 * 48 + 8 * 0 + 7] = vertices[0 * 48 + 8 * 2 + 7] = vertices[0 * 48 + 8 * 4 + 7] = texture.y;
		vertices[0 * 48 + 8 * 1 + 6] = vertices[0 * 48 + 8 * 2 + 6] = vertices[0 * 48 + 8 * 3 + 6] = texture.x + texture.z;
		vertices[0 * 48 + 8 * 1 + 7] = vertices[0 * 48 + 8 * 3 + 7] = vertices[0 * 48 + 8 * 5 + 7] = texture.y + texture.z;

		vertices[1 * 48 + 8 * 0 + 6] = vertices[1 * 48 + 8 * 4 + 6] = vertices[1 * 48 + 8 * 5 + 6] = texture.x;
		vertices[1 * 48 + 8 * 0 + 7] = vertices[1 * 48 + 8 * 1 + 7] = vertices[1 * 48 + 8 * 5 + 7] = texture.y;
		vertices[1 * 48 + 8 * 1 + 6] = vertices[1 * 48 + 8 * 2 + 6] = vertices[1 * 48 + 8 * 3 + 6] = texture.x + texture.z;
		vertices[1 * 48 + 8 * 2 + 7] = vertices[1 * 48 + 8 * 3 + 7] = vertices[1 * 48 + 8 * 4 + 7] = texture.y + texture.z;
	}
	else {
		vertices[2 * 48 + 8 * 1 + 6] = vertices[2 * 48 + 8 * 2 + 6] = vertices[2 * 48 + 8 * 3 + 6] = texture.x;
		vertices[2 * 48 + 8 * 2 + 7] = vertices[2 * 48 + 8 * 3 + 7] = vertices[2 * 48 + 8 * 4 + 7] = texture.y;
		vertices[2 * 48 + 8 * 0 + 6] = vertices[2 * 48 + 8 * 4 + 6] = vertices[2 * 48 + 8 * 5 + 6] = texture.x + texture.z;
		vertices[2 * 48 + 8 * 0 + 7] = vertices[2 * 48 + 8 * 1 + 7] = vertices[2 * 48 + 8 * 5 + 7] = texture.y + texture.z;

		vertices[3 * 48 + 8 * 0 + 6] = vertices[3 * 48 + 8 * 4 + 6] = vertices[3 * 48 + 8 * 5 + 6] = texture.x;
		vertices[3 * 48 + 8 * 1 + 7] = vertices[3 * 48 + 8 * 3 + 7] = vertices[3 * 48 + 8 * 5 + 7] = texture.y;
		vertices[3 * 48 + 8 * 1 + 6] = vertices[3 * 48 + 8 * 2 + 6] = vertices[3 * 48 + 8 * 3 + 6] = texture.x + texture.z;
		vertices[3 * 48 + 8 * 0 + 7] = vertices[3 * 48 + 8 * 2 + 7] = vertices[3 * 48 + 8 * 4 + 7] = texture.y + texture.z;
	}

	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glBindVertexArray(cubeVAO);
	glDrawArrays(GL_TRIANGLES, 0, 36);
	glBindVertexArray(0);
}
