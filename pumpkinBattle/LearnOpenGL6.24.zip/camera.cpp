#include "camera.h"

bool tcmp(pair<double, Point3D> a, pair<double, Point3D> b) { return a.first < b.first; }
