#pragma once
#include "camera.h"
#include "Wall.h"
#include "Model.h"

class Monster : public OurModel{
public:
	Monster(const char *s, Point3D pos, double size,
		Point3D centerpos = Point3D(0, 0, 0), double xlength = 0, double ylength = 0, double zlength = 0) :
		OurModel(s, pos, size, 1, centerpos, xlength, ylength, zlength) {}
	void Trymove(Point3D goal, double movelen) {
		goal.y = pos.y;
		if ((goal - pos).length() > 1) {
			Front = goal - pos;
			pos = pos + Front.resize(movelen);
		}
		Front = Front.resize(1);
		
		Point3D temp = Point3D(0, 1, 0) * Front;
		if (sgn(temp.length()) != 0)Right = temp;
		Right = Right.resize(1);

		Up = Front * Right;
		Up = Up.resize(1);
	}
};