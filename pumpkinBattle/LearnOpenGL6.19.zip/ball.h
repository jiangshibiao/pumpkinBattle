#ifndef _BALL_
#define _BALL_
#include "point.h"
#include <algorithm>
#include <vector>

using namespace std;

struct Ball {
public:
	Ball(Point3D posi, Point3D velo, double radi = 1., int exstime = 400) :
		posi(posi), velo(velo), radi(radi), exstime(exstime) {};
	Point3D posi, velo;
	double radi;
	int exstime;
	pair<double, Point3D> collide(const Point3D &A, const Point3D &B, const Point3D &C)const;
	static void CollBalls();
};

extern vector<Ball*> BallManager;

#endif