#include "ball.h"
#include "Wall.h"

vector<Ball*> BallManager;

pair<double, Point3D> Ball::collide(const Point3D &A, const Point3D &B, const Point3D &C) const {
	double projdis = pointtoplanedistance(posi, A, B, C);
	if (projdis < 0)return make_pair(1, velo);
	if (pointtoplanedistance(posi + velo, A, B, C) > 0)return make_pair(1, velo);
	Point3D temp = ((C - A) * (B - A)).resize(1);
	if (sgn(pointtoplanedistance(posi, A, B, posi + velo)) < 0)return make_pair(1, velo);
	if (sgn(pointtoplanedistance(posi, B, C, posi + velo)) < 0)return make_pair(1, velo);
	if (sgn(pointtoplanedistance(posi, C, A, posi + velo)) < 0)return make_pair(1, velo);
	return make_pair((projdis - 0) / -(velo%temp), velo - temp.resize(velo%temp * 2));
}

void Ball::CollBalls(){
	for (Ball *pball : BallManager) {
		if (pball->exstime <= 0)continue;//this should be deleted???
		pball->exstime -= 1;
		if (sgn(pball->velo.length()) <= 0) {
			//pball->velo = pball->velo + Point3D(0., -0.001, 0.);
			continue;
		}
		//printf("%d ", ++cnt); pball->posi.Print(); puts("");

		pair<double, Point3D>coll = make_pair(1, pball->velo);
		for (Wall *pwall : WallManager) {
			int siz = pwall->allface.size();
			for (int i = 0; i < siz; i += 4) {
				pair<double, Point3D>temp = pball->collide(pwall->allface[i + 2], pwall->allface[i + 1], pwall->allface[i]);
				if (temp.first < coll.first)coll = temp;
				temp = pball->collide(pwall->allface[i], pwall->allface[i + 3], pwall->allface[i + 2]);
				if (temp.first < coll.first)coll = temp;
			}
		}
		pball->posi = pball->posi + pball->velo * coll.first;
		pball->velo = coll.second;
	}
}
